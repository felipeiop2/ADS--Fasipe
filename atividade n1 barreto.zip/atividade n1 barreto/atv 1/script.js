
 function clicar(){
    let res = window.document.getElementById("resultado");
    res.innerHTML = `Ola`
 }
